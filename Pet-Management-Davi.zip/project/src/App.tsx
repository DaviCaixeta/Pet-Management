import React, { useState, useEffect } from 'react';
import { collection, addDoc, updateDoc, deleteDoc, doc, getDocs, query, where, getDoc } from 'firebase/firestore';
import { db, auth } from './lib/firebase';
import { Pet, MedicalRecord } from './types';
import { PetCard } from './components/PetCard';
import { PetForm } from './components/PetForm';
import { MedicalRecordForm } from './components/MedicalRecordForm';
import { PetDetails } from './components/PetDetails';
import { SocialFeed } from './components/SocialFeed';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { PawPrint, Plus, Users, UserCircle } from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';
import { onAuthStateChanged, signOut } from 'firebase/auth';

function App() {
  const [pets, setPets] = useState<Pet[]>([]);
  const [showPetForm, setShowPetForm] = useState(false);
  const [selectedPet, setSelectedPet] = useState<Pet | undefined>();
  const [viewingPet, setViewingPet] = useState<Pet | undefined>();
  const [activeTab, setActiveTab] = useState<'pets' | 'social'>('pets');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [user, setUser] = useState(auth.currentUser);
  const [userProfile, setUserProfile] = useState<{
    username: string;
    avatarUrl: string;
  } | null>(null);
  const [medicalFormData, setMedicalFormData] = useState<{
    petId: string;
    type: 'medication' | 'vet-visit' | 'illness';
  } | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      if (!user) {
        setShowAuthModal(true);
        setUserProfile(null);
        setPets([]);
      } else {
        loadUserProfile(user.uid);
        loadPets(user.uid);
      }
    });

    return () => unsubscribe();
  }, []);

  const loadUserProfile = async (userId: string) => {
    try {
      const userDocRef = doc(db, 'users', userId);
      const userDocSnap = await getDoc(userDocRef);
      
      if (userDocSnap.exists()) {
        const data = userDocSnap.data();
        setUserProfile({
          username: data.username || '',
          avatarUrl: data.avatarUrl || ''
        });
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      toast.error('Failed to load user profile');
    }
  };

  const loadPets = async (userId: string) => {
    try {
      const petsQuery = query(
        collection(db, 'pets'),
        where('userId', '==', userId)
      );
      const snapshot = await getDocs(petsQuery);
      const petsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Pet[];
      
      setPets(petsData.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error('Error loading pets:', error);
      toast.error('Failed to load pets');
    }
  };

  const handleAddPet = async (petData: Omit<Pet, 'id'>) => {
    if (!user) {
      toast.error('Please login to add a pet');
      return;
    }
    
    try {
      const newPet = {
        ...petData,
        userId: user.uid,
        createdAt: Date.now()
      };
      
      await addDoc(collection(db, 'pets'), newPet);
      toast.success('Pet added successfully');
      loadPets(user.uid);
      setShowPetForm(false);
    } catch (error) {
      console.error('Error adding pet:', error);
      toast.error('Failed to add pet');
    }
  };

  const handleUpdatePet = async (petData: Omit<Pet, 'id'>) => {
    if (!selectedPet || !user) {
      toast.error('Please login to update pet');
      return;
    }
    
    try {
      const petDoc = await getDoc(doc(db, 'pets', selectedPet.id));
      if (petDoc.exists() && petDoc.data().userId === user.uid) {
        await updateDoc(doc(db, 'pets', selectedPet.id), petData);
        toast.success('Pet updated successfully');
        loadPets(user.uid);
        setShowPetForm(false);
        setSelectedPet(undefined);
      } else {
        toast.error('You do not have permission to update this pet');
      }
    } catch (error) {
      console.error('Error updating pet:', error);
      toast.error('Failed to update pet');
    }
  };

  const handleDeletePet = async (id: string) => {
    if (!user) {
      toast.error('Please login to delete pet');
      return;
    }
    
    if (!confirm('Are you sure you want to delete this pet?')) return;
    
    try {
      const petDoc = await getDoc(doc(db, 'pets', id));
      if (petDoc.exists() && petDoc.data().userId === user.uid) {
        await deleteDoc(doc(db, 'pets', id));
        toast.success('Pet deleted successfully');
        loadPets(user.uid);
      } else {
        toast.error('You do not have permission to delete this pet');
      }
    } catch (error) {
      console.error('Error deleting pet:', error);
      toast.error('Failed to delete pet');
    }
  };

  const handleAddMedicalRecord = async (recordData: Omit<MedicalRecord, 'id'>) => {
    if (!user) {
      toast.error('Please login to add medical record');
      return;
    }
    
    try {
      const petDoc = await getDoc(doc(db, 'pets', recordData.petId));
      if (petDoc.exists() && petDoc.data().userId === user.uid) {
        await addDoc(collection(db, 'medicalRecords'), {
          ...recordData,
          userId: user.uid,
          createdAt: Date.now()
        });
        toast.success('Record added successfully');
        setMedicalFormData(null);
      } else {
        toast.error('You do not have permission to add records to this pet');
      }
    } catch (error) {
      console.error('Error adding medical record:', error);
      toast.error('Failed to add record');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success('Logged out successfully');
      setShowAuthModal(true);
    } catch (error) {
      console.error('Error signing out:', error);
      toast.error('Failed to log out');
    }
  };

  if (!user && !showAuthModal) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <PawPrint className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Pet Manager</h1>
            </div>
            {user && (
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setShowProfileModal(true)}
                  className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
                >
                  {userProfile?.avatarUrl ? (
                    <img
                      src={userProfile.avatarUrl}
                      alt={userProfile.username}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <UserCircle size={32} />
                  )}
                  <span>{userProfile?.username || user.email}</span>
                </button>
                <button
                  onClick={handleLogout}
                  className="text-sm text-gray-600 hover:text-gray-900"
                >
                  Logout
                </button>
              </div>
            )}
          </div>

          {user && (
            <div className="mt-4 flex gap-4 border-b">
              <button
                onClick={() => setActiveTab('pets')}
                className={`px-4 py-2 font-medium ${
                  activeTab === 'pets'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                My Pets
              </button>
              <button
                onClick={() => setActiveTab('social')}
                className={`px-4 py-2 font-medium flex items-center gap-2 ${
                  activeTab === 'social'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <Users size={20} />
                Social Feed
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {user && activeTab === 'pets' ? (
          <>
            <div className="mb-6 flex justify-end">
              <button
                onClick={() => setShowPetForm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <Plus size={20} />
                Add Pet
              </button>
            </div>

            {pets.length === 0 ? (
              <div className="text-center py-12">
                <PawPrint className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No pets</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by adding a new pet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pets.map(pet => (
                  <PetCard
                    key={pet.id}
                    pet={pet}
                    onEdit={(pet) => {
                      setSelectedPet(pet);
                      setShowPetForm(true);
                    }}
                    onDelete={handleDeletePet}
                    onAddRecord={(petId, type) => setMedicalFormData({ petId, type })}
                    onViewDetails={(pet) => setViewingPet(pet)}
                  />
                ))}
              </div>
            )}
          </>
        ) : user && (
          <SocialFeed userProfile={userProfile} />
        )}
      </main>

      {showPetForm && (
        <PetForm
          pet={selectedPet}
          onSubmit={selectedPet ? handleUpdatePet : handleAddPet}
          onClose={() => {
            setShowPetForm(false);
            setSelectedPet(undefined);
          }}
        />
      )}

      {medicalFormData && user && (
        <MedicalRecordForm
          petId={medicalFormData.petId}
          userId={user.uid}
          type={medicalFormData.type}
          onSubmit={handleAddMedicalRecord}
          onClose={() => setMedicalFormData(null)}
        />
      )}

      {viewingPet && (
        <PetDetails
          pet={viewingPet}
          onClose={() => setViewingPet(undefined)}
        />
      )}

      {showAuthModal && (
        <AuthModal 
          onClose={() => user && setShowAuthModal(false)}
          onSuccess={(profile) => {
            setUserProfile(profile);
            setShowAuthModal(false);
          }}
        />
      )}

      {showProfileModal && (
        <UserProfileModal
          currentProfile={userProfile}
          onClose={() => setShowProfileModal(false)}
          onUpdate={(profile) => {
            setUserProfile(profile);
            setShowProfileModal(false);
          }}
        />
      )}
    </div>
  );
}

export default App;