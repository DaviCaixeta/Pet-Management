import { useState, useCallback } from 'react';
import { collection, doc, getDoc, setDoc, addDoc, updateDoc, deleteDoc, getDocs, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'react-hot-toast';

export function useFirestore(collectionName: string) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const getDocument = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      const docRef = doc(db, collectionName, id);
      const docSnap = await getDoc(docRef);
      setLoading(false);
      
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() };
      }
      return null;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error fetching document: ${error.message}`);
      return null;
    }
  }, [collectionName]);

  const getDocuments = useCallback(async (userId: string) => {
    setLoading(true);
    setError(null);
    try {
      const q = query(collection(db, collectionName), where('userId', '==', userId));
      const querySnapshot = await getDocs(q);
      const documents = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setLoading(false);
      return documents;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error fetching documents: ${error.message}`);
      return [];
    }
  }, [collectionName]);

  const addDocument = useCallback(async (data: any) => {
    setLoading(true);
    setError(null);
    try {
      const docRef = await addDoc(collection(db, collectionName), {
        ...data,
        createdAt: Date.now()
      });
      setLoading(false);
      toast.success('Document added successfully');
      return docRef.id;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error adding document: ${error.message}`);
      return null;
    }
  }, [collectionName]);

  const updateDocument = useCallback(async (id: string, data: any) => {
    setLoading(true);
    setError(null);
    try {
      const docRef = doc(db, collectionName, id);
      await updateDoc(docRef, data);
      setLoading(false);
      toast.success('Document updated successfully');
      return true;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error updating document: ${error.message}`);
      return false;
    }
  }, [collectionName]);

  const deleteDocument = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      await deleteDoc(doc(db, collectionName, id));
      setLoading(false);
      toast.success('Document deleted successfully');
      return true;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error deleting document: ${error.message}`);
      return false;
    }
  }, [collectionName]);

  const setDocument = useCallback(async (id: string, data: any) => {
    setLoading(true);
    setError(null);
    try {
      await setDoc(doc(db, collectionName, id), {
        ...data,
        createdAt: Date.now()
      });
      setLoading(false);
      toast.success('Document set successfully');
      return true;
    } catch (err) {
      const error = err as Error;
      setError(error);
      setLoading(false);
      toast.error(`Error setting document: ${error.message}`);
      return false;
    }
  }, [collectionName]);

  return {
    loading,
    error,
    getDocument,
    getDocuments,
    addDocument,
    updateDocument,
    deleteDocument,
    setDocument
  };
}