import { useState, useEffect } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import type { UserProfile } from '../types';
import { toast } from 'react-hot-toast';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUserProfile = async (userId: string) => {
      try {
        const userDocRef = doc(db, 'users', userId);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          setProfile({ id: userDoc.id, ...userDoc.data() } as UserProfile);
        } else {
          // Create default profile
          const defaultProfile: Omit<UserProfile, 'id'> = {
            email: user?.email || '',
            username: user?.displayName || user?.email?.split('@')[0] || 'User',
            createdAt: Date.now()
          };

          await setDoc(userDocRef, defaultProfile);
          setProfile({ id: userId, ...defaultProfile });
          toast.success('Profile created successfully');
        }
      } catch (error) {
        console.error('Error loading user profile:', error);
        toast.error('Failed to load user profile. Please try refreshing the page.');
      }
    };

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        await loadUserProfile(currentUser.uid);
      } else {
        setProfile(null);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const updateProfile = async (updates: Partial<Omit<UserProfile, 'id' | 'email'>>) => {
    if (!user) return;

    try {
      const userDocRef = doc(db, 'users', user.uid);
      await setDoc(userDocRef, updates, { merge: true });
      setProfile(prev => prev ? { ...prev, ...updates } : null);
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    }
  };

  return { 
    user, 
    profile, 
    loading,
    updateProfile
  };
}