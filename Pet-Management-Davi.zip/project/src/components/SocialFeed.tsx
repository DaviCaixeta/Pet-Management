import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, addDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Post } from '../types';
import { ImageUpload } from './ImageUpload';
import { Heart, MessageCircle, Share2 } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { format } from 'date-fns';
import { fakePosts } from '../lib/fakePosts';

interface SocialFeedProps {
  userProfile: { username: string; avatarUrl: string } | null;
}

export function SocialFeed({ userProfile }: SocialFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPost, setNewPost] = useState({ content: '', imageUrl: '' });
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      // Load real posts from Firebase
      const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50));
      const snapshot = await getDocs(q);
      const realPosts = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Post[];

      // Combine real posts with fake posts
      const combinedPosts = [
        ...realPosts,
        ...fakePosts.map((post, index) => ({
          ...post,
          id: `fake-${index}` // Add fake IDs for fake posts
        }))
      ].sort((a, b) => b.createdAt - a.createdAt);

      setPosts(combinedPosts);
    } catch (error) {
      console.error('Error loading posts:', error);
      toast.error('Failed to load posts');
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !userProfile) {
      toast.error('Please login to create a post');
      return;
    }

    try {
      const user = auth.currentUser;
      await addDoc(collection(db, 'posts'), {
        userId: user.uid,
        username: userProfile.username,
        userAvatar: userProfile.avatarUrl,
        content: newPost.content,
        imageUrl: newPost.imageUrl,
        createdAt: Date.now(),
        likes: 0
      });

      setNewPost({ content: '', imageUrl: '' });
      setIsCreating(false);
      toast.success('Post created successfully');
      loadPosts();
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post');
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8">
      {auth.currentUser && (
        <div className="mb-8">
          {isCreating ? (
            <form onSubmit={handleCreatePost} className="bg-white rounded-lg shadow p-4 space-y-4">
              <textarea
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                placeholder="Share something about your pets..."
                className="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500"
                rows={3}
                required
              />
              <ImageUpload
                onImageUploaded={(url) => setNewPost({ ...newPost, imageUrl: url })}
                currentImage={newPost.imageUrl}
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 text-sm text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700"
                >
                  Post
                </button>
              </div>
            </form>
          ) : (
            <button
              onClick={() => setIsCreating(true)}
              className="w-full px-4 py-3 text-left text-gray-500 bg-white rounded-lg shadow hover:bg-gray-50"
            >
              Share something about your pets...
            </button>
          )}
        </div>
      )}

      <div className="space-y-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white rounded-lg shadow">
            <div className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <img
                  src={post.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                  alt={post.username}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-medium">{post.username}</h3>
                  <p className="text-sm text-gray-500">
                    {format(post.createdAt, 'MMM d, yyyy')}
                  </p>
                </div>
              </div>

              <p className="text-gray-800 mb-4">{post.content}</p>

              {post.imageUrl && (
                <img
                  src={post.imageUrl}
                  alt="Post"
                  className="w-full rounded-lg mb-4"
                />
              )}

              <div className="flex items-center gap-6 text-gray-500">
                <button className="flex items-center gap-2 hover:text-red-500">
                  <Heart size={20} />
                  <span>{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 hover:text-blue-500">
                  <MessageCircle size={20} />
                  <span>Comment</span>
                </button>
                <button className="flex items-center gap-2 hover:text-green-500">
                  <Share2 size={20} />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}