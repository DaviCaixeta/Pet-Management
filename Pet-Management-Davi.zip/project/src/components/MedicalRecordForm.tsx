import React, { useState } from 'react';
import { useFirestore } from '../hooks/useFirestore';
import type { MedicalRecord } from '../types';
import { Dialog } from './Dialog';

interface Props {
  petId: string;
  userId: string;
  type: MedicalRecord['type'];
  onClose: () => void;
  onSubmit: (record: Omit<MedicalRecord, 'id'>) => Promise<void>;
}

export function MedicalRecordForm({ petId, userId, type, onClose, onSubmit }: Props) {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const record: Omit<MedicalRecord, 'id'> = {
        petId,
        userId,
        type,
        date,
        description,
        createdAt: Date.now()
      };

      await onSubmit(record);
      onClose();
    } catch (error) {
      console.error('Error submitting medical record:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog
      title={`Add ${type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())} Record`}
      onClose={onClose}
    >
      <form onSubmit={handleSubmit} className="space-y-6 px-1">
        <div className="space-y-2">
          <label htmlFor="date" className="block text-sm font-medium text-gray-700">
            Date
          </label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2"
            required
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2"
            placeholder="Enter the details of the medical record..."
            required
          />
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {loading ? 'Adding...' : 'Add Record'}
          </button>
        </div>
      </form>
    </Dialog>
  );
}