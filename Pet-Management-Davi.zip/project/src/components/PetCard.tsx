import React from 'react';
import { Pet } from '../types';
import { Pencil, Trash2, Pill, Stethoscope, Heart, Eye } from 'lucide-react';

interface PetCardProps {
  pet: Pet;
  onEdit: (pet: Pet) => void;
  onDelete: (id: string) => void;
  onAddRecord: (petId: string, type: 'medication' | 'vet-visit' | 'illness') => void;
  onViewDetails: (pet: Pet) => void;
}

export function PetCard({ pet, onEdit, onDelete, onAddRecord, onViewDetails }: PetCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={pet.photoUrl || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1'}
        alt={pet.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800">{pet.name}</h3>
        <div className="mt-2 text-gray-600">
          <p>Type: {pet.type}</p>
          <p>Age: {pet.age} years</p>
        </div>
        
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => onAddRecord(pet.id, 'medication')}
            className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200"
          >
            <Pill size={16} />
            <span>Medication</span>
          </button>
          <button
            onClick={() => onAddRecord(pet.id, 'vet-visit')}
            className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full hover:bg-green-200"
          >
            <Stethoscope size={16} />
            <span>Vet Visit</span>
          </button>
          <button
            onClick={() => onAddRecord(pet.id, 'illness')}
            className="flex items-center gap-1 px-3 py-1 bg-red-100 text-red-700 rounded-full hover:bg-red-200"
          >
            <Heart size={16} />
            <span>Illness</span>
          </button>
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button
            onClick={() => onViewDetails(pet)}
            className="p-2 text-gray-600 hover:bg-gray-50 rounded-full"
            title="View Details"
          >
            <Eye size={18} />
          </button>
          <button
            onClick={() => onEdit(pet)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
            title="Edit Pet"
          >
            <Pencil size={18} />
          </button>
          <button
            onClick={() => onDelete(pet.id)}
            className="p-2 text-red-600 hover:bg-red-50 rounded-full"
            title="Delete Pet"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}