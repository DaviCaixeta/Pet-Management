import React, { useState, useEffect } from 'react';
import { Pet } from '../types';
import { X } from 'lucide-react';
import { ImageUpload } from './ImageUpload';

interface PetFormProps {
  pet?: Pet;
  onSubmit: (pet: Omit<Pet, 'id'>) => Promise<void>;
  onClose: () => void;
}

const PET_TYPES = [
  'Dog',
  'Cat',
  'Bird',
  'Rabbit',
  'Hamster',
  'Guinea Pig',
  'Fish',
  'Turtle',
  'Ferret',
  'Parrot',
  'Gecko',
  'Snake',
  'Bearded Dragon',
  'Hedgehog',
  'Chinchilla'
];

export function PetForm({ pet, onSubmit, onClose }: PetFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    age: '',
    photoUrl: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (pet) {
      setFormData({
        name: pet.name,
        type: pet.type,
        age: pet.age.toString(),
        photoUrl: pet.photoUrl || ''
      });
    }
  }, [pet]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await onSubmit({
        name: formData.name,
        type: formData.type,
        age: parseInt(formData.age),
        photoUrl: formData.photoUrl
      });
      onClose();
    } catch (error) {
      console.error('Error submitting pet form:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUploaded = (url: string) => {
    setFormData(prev => ({ ...prev, photoUrl: url }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">{pet ? 'Edit Pet' : 'Add New Pet'}</h2>
          <button 
            onClick={onClose} 
            className="text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 rounded-full p-1"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Photo</label>
            <ImageUpload 
              onImageUploaded={handleImageUploaded}
              currentImage={formData.photoUrl}
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2"
              placeholder="Enter pet's name"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Type</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2"
              required
            >
              <option value="">Select a pet type</option>
              {PET_TYPES.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Age</label>
            <input
              type="number"
              value={formData.age}
              onChange={(e) => setFormData({ ...formData, age: e.target.value })}
              className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-2"
              placeholder="Enter pet's age"
              required
              min="0"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {loading ? (pet ? 'Updating...' : 'Adding...') : (pet ? 'Update' : 'Add') + ' Pet'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}