import React, { useState } from 'react';
import { Loader2, Upload } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface ImageUploadProps {
  onImageUploaded: (url: string) => void;
  currentImage?: string;
}

export function ImageUpload({ onImageUploaded, currentImage }: ImageUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string>(currentImage || '');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      
      // Create preview immediately
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);

      // Create form data
      const formData = new FormData();
      formData.append('image', file);

      // Upload to ImgBB
      const response = await fetch('https://api.imgbb.com/1/upload?key=f535ba822e59179e8293f924bc90b2ad', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();
      
      if (data.success) {
        onImageUploaded(data.data.display_url);
        toast.success('Image uploaded successfully');
      } else {
        throw new Error(data.error?.message || 'Upload failed');
      }
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error?.message || 'Failed to upload image');
      setPreview(currentImage || '');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="relative">
      <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md ${
        uploading ? 'border-gray-300 bg-gray-50' : 'border-gray-300 hover:border-blue-400'
      }`}>
        <div className="space-y-1 text-center">
          {preview ? (
            <img
              src={preview}
              alt="Preview"
              className="mx-auto h-32 w-32 object-cover rounded-lg"
            />
          ) : (
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
          )}
          
          <div className="flex justify-center text-sm text-gray-600">
            <label className={`relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500 ${
              uploading ? 'cursor-not-allowed opacity-50' : ''
            }`}>
              <span>{uploading ? 'Uploading...' : 'Upload a file'}</span>
              <input
                type="file"
                className="sr-only"
                accept="image/*"
                onChange={handleFileChange}
                disabled={uploading}
                onClick={(e) => (e.target as HTMLInputElement).value = ''}
              />
            </label>
          </div>
          <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
        </div>
      </div>
      
      {uploading && (
        <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center">
          <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
        </div>
      )}
    </div>
  );
}