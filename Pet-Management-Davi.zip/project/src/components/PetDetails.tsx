import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Pet, MedicalRecord } from '../types';
import { format } from 'date-fns';
import { X, Pill, Stethoscope, Heart } from 'lucide-react';

interface PetDetailsProps {
  pet: Pet;
  onClose: () => void;
}

export function PetDetails({ pet, onClose }: PetDetailsProps) {
  const [records, setRecords] = useState<MedicalRecord[]>([]);

  useEffect(() => {
    loadMedicalRecords();
  }, [pet.id]);

  const loadMedicalRecords = async () => {
    try {
      const q = query(
        collection(db, 'medicalRecords'),
        where('petId', '==', pet.id)
      );
      
      const snapshot = await getDocs(q);
      const recordsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as MedicalRecord[];
      
      const sortedRecords = recordsData.sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      
      setRecords(sortedRecords);
    } catch (error) {
      console.error('Error loading medical records:', error);
    }
  };

  const getRecordIcon = (type: string) => {
    switch (type) {
      case 'medication':
        return <Pill className="text-blue-600" />;
      case 'vet-visit':
        return <Stethoscope className="text-green-600" />;
      case 'illness':
        return <Heart className="text-red-600" />;
      default:
        return null;
    }
  };

  const getRecordTypeColor = (type: string) => {
    switch (type) {
      case 'medication':
        return 'bg-blue-50 text-blue-700';
      case 'vet-visit':
        return 'bg-green-50 text-green-700';
      case 'illness':
        return 'bg-red-50 text-red-700';
      default:
        return 'bg-gray-50 text-gray-700';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg w-full max-w-3xl my-8">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-semibold text-gray-900">Pet Details</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="w-full md:w-1/3">
              <img
                src={pet.photoUrl || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1'}
                alt={pet.name}
                className="w-full h-48 object-cover rounded-lg shadow-md"
              />
              <div className="mt-4 space-y-2">
                <h3 className="text-xl font-semibold text-gray-900">{pet.name}</h3>
                <p className="text-gray-600">Type: {pet.type}</p>
                <p className="text-gray-600">Age: {pet.age} years</p>
              </div>
            </div>

            <div className="w-full md:w-2/3">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Medical History</h3>
              
              {records.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No medical records found</p>
              ) : (
                <div className="space-y-4">
                  {records.map((record) => (
                    <div
                      key={record.id}
                      className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {getRecordIcon(record.type)}
                          <span className={`px-2 py-1 rounded-full text-sm ${getRecordTypeColor(record.type)}`}>
                            {record.type.charAt(0).toUpperCase() + record.type.slice(1)}
                          </span>
                        </div>
                        <span className="text-sm text-gray-500">
                          {format(new Date(record.date), 'MMM d, yyyy')}
                        </span>
                      </div>
                      
                      <p className="text-gray-900 font-medium">{record.description}</p>
                      {record.notes && (
                        <p className="mt-2 text-gray-600 text-sm">{record.notes}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}