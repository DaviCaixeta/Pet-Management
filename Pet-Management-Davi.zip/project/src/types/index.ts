export interface Pet {
  id: string;
  name: string;
  type: string;
  age: number;
  imageUrl?: string;
  userId: string;
  createdAt: number;
}

export interface MedicalRecord {
  id: string;
  petId: string;
  userId: string;
  type: 'medication' | 'vet-visit' | 'illness';
  date: string;
  description: string;
  createdAt: number;
}

export interface UserProfile {
  id: string;
  username: string;
  avatarUrl?: string;
  email: string;
  createdAt: number;
}