import { Post } from '../types';

export const fakePosts: Omit<Post, 'id'>[] = [
  {
    userId: 'fake1',
    username: 'EmmaVet',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
    content: '🐾 Pro Tip: Regular dental care is crucial for your pet\'s health! Did you know that 80% of dogs show signs of oral disease by age 3? Start brushing their teeth early and make it a fun routine! #PetCare #VetAdvice',
    imageUrl: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b',
    createdAt: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
    likes: 45
  },
  {
    userId: 'fake2',
    username: 'CatLady',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
    content: 'Just discovered an amazing trick for anxious cats during thunderstorms! Creating a cozy hideout with their favorite blanket and some calming music works wonders. Luna is so much calmer now! 🐱 #CatCare #PetTips',
    imageUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba',
    createdAt: Date.now() - 1000 * 60 * 60 * 4, // 4 hours ago
    likes: 89
  },
  {
    userId: 'fake3',
    username: 'PawsomeTrainer',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d',
    content: '🎓 Training Success Story: Max went from pulling on leash to perfect loose-leash walking in just 3 weeks! The key? Consistency and positive reinforcement. Remember, every dog learns at their own pace! #DogTraining',
    imageUrl: 'https://images.unsplash.com/photo-1617895153857-82fe79adfcd4',
    createdAt: Date.now() - 1000 * 60 * 60 * 6, // 6 hours ago
    likes: 156
  },
  {
    userId: 'fake4',
    username: 'BunnyMom',
    userAvatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb',
    content: 'DIY Rabbit Enrichment Toys! 🐰 Made these simple cardboard tunnels and treat puzzles today. It\'s amazing how something so simple can bring them so much joy! Swipe for tutorial #RabbitCare #PetEnrichment',
    imageUrl: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308',
    createdAt: Date.now() - 1000 * 60 * 60 * 12, // 12 hours ago
    likes: 67
  },
  {
    userId: 'fake5',
    username: 'ExoticVet',
    userAvatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12',
    content: 'PSA: Bearded Dragons need UVB lighting even on cloudy days! 🦎 Just upgraded my setup with a new lighting system. Remember to replace UVB bulbs every 6 months for optimal health! #ExoticPets #ReptiCare',
    imageUrl: 'https://images.unsplash.com/photo-1534295983867-d6d8f7288d2f',
    createdAt: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
    likes: 92
  },
  {
    userId: 'fake6',
    username: 'ParrotWhisperer',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
    content: '🦜 Enrichment Tip: Rotate your bird\'s toys weekly to prevent boredom! Here\'s Rico mastering his new puzzle toy. Mental stimulation is just as important as physical exercise! #ParrotLife #BirdCare',
    imageUrl: 'https://images.unsplash.com/photo-1552728089-57bdde30beb3',
    createdAt: Date.now() - 1000 * 60 * 60 * 48, // 2 days ago
    likes: 134
  },
  {
    userId: 'fake7',
    username: 'AquariumPro',
    userAvatar: 'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e',
    content: '🐠 New Research: Live plants in aquariums don\'t just look beautiful - they improve water quality and reduce stress in fish! Here\'s my latest aquascape setup. #Aquarium #FishKeeping',
    imageUrl: 'https://images.unsplash.com/photo-1584275779769-31b4fb837f2c',
    createdAt: Date.now() - 1000 * 60 * 60 * 72, // 3 days ago
    likes: 218
  },
  {
    userId: 'fake8',
    username: 'RescueHero',
    userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6',
    content: 'Happy adoption day to this sweet girl! 🐕 Remember: when adopting, personality fit is more important than breed or looks. She\'s settled in perfectly! #AdoptDontShop #RescueDogs',
    imageUrl: 'https://images.unsplash.com/photo-1601979031925-424e53b6caaa',
    createdAt: Date.now() - 1000 * 60 * 60 * 96, // 4 days ago
    likes: 445
  }
];