import { initializeApp } from 'firebase/app';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyDOM6-FmtwRWquJ7C2fhuuGVs3SRJdYcbU",
  authDomain: "pets2-77345.firebaseapp.com",
  projectId: "pets2-77345",
  storageBucket: "pets2-77345.firebasestorage.app",
  messagingSenderId: "185751069038",
  appId: "1:185751069038:web:abdc1f0246b645a824617f"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Enable offline persistence
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code === 'unimplemented') {
    console.warn('The current browser doesn\'t support persistence.');
  }
});